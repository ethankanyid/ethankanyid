#!/bin/bash

clang-format -i "$ZED_FILE"
