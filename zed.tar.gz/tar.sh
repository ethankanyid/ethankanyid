#!/bin/bash

# Get the current directory
current_directory=$(pwd)

# Define the default tar file name based on the current directory name
default_tar_file_name="$(basename "$current_directory").tar.gz"

# Check if any .tar.gz file exists in the directory
existing_tar_file=$(find "$current_directory" -maxdepth 1 -name "*.tar.gz" | head -n 1)

if [ -n "$existing_tar_file" ]; then
    # If a .tar.gz file is found, use the first one found (could be the default or any tar file)
    tar_file_name="$existing_tar_file"
else
    # Prompt the user for a custom tar file name
    echo "Enter a tar file name (default: $default_tar_file_name):"
    read user_input

    # Use the user's input or default to the directory name if the input is empty
    if [ -z "$user_input" ]; then
        tar_file_name="$default_tar_file_name"
    else
        tar_file_name="$user_input.tar.gz"
    fi
fi

# Check if the tar file already exists (for overwrite confirmation)
if [ -f "$tar_file_name" ]; then
    # Prompt user to overwrite the existing file
    echo "The file '$(basename "$tar_file_name")' already exists. Do you want to overwrite it? (y/n)"
    read overwrite_input
    if [[ "$overwrite_input" != "y" && "$overwrite_input" != "Y" ]]; then
        echo "Aborted. The tar file was not created."
        exit 1
    fi
fi

# Create the tarball
tar -czvf "$tar_file_name" -C "$current_directory" .

# Confirm the action
if [ $? -eq 0 ]; then
    echo "Successfully created tarball: $tar_file_name"
else
    echo "Error: Failed to create tarball"
    exit 2
fi
